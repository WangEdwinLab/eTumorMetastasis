library(cluster)
Args <- commandArgs();

# -------------------------------------------------------------------------------------------------------------------- #
# Use the fisher test as follows: a is the number of essential samples that cluster in group 1, b those that cluster   #
# in group 2, c is the number of non essential samples that cluster in group 1 and d those that cluster in group 2.    #
# -------------------------------------------------------------------------------------------------------------------- #
go     <-     Args[3];
gset     <-     Args[5];
dataSet <- Args[4];
dSets     <-    as.numeric(200);
run     <-     Args[6];

wrkDir <- paste('/work/knode05/milanesej/metastasis/BRCA/MSS/emt/founding_within/',go,sep="");

#Coverage across all DS
psdSets    =     0.8;
minSet    =    dSets-dSets*psdSets;
#PVal
minPvl    =    0.005

# ------>    Load the gene sets.
gsFile <- paste(wrkDir,"/GeneSet/",gset,'.txt',sep='');
gsData <- read.table (gsFile, sep=',', header = F);
gsData <- as.matrix( gsData );
# ------>    Done.   

# ------>    Load the Expression data.
xprFile <- '/work/knode05/milanesej/metastasis/BRCA/MSS/emt/founding_within/all_scaled_prop_within.csv';
xprData <- read.table(xprFile ,header=T, sep=',');
xprData <- xprData[1:nrow(xprData),4:ncol(xprData)];
PValues <- matrix(1,nrow(gsData),dSets);
colnames(PValues) <- paste(rep("Dset",ncol(PValues)),c(1:ncol(PValues)),sep="")
PsdSet     <- matrix(0,nrow(gsData),1);
# ------>    Done.

dsFile <- paste(wrkDir,"/DataSet/",dataSet,".txt",sep='');
dsData <- read.table (dsFile, sep=',', header = T);

# ------>    The objective is 90% of the data sets should pass with a pvalue <= 0.05.
#for( dsId in 1:20){ 
for ( dsId in 1:dSets){
curDat <- dsData[dsData$DatsetId==dsId,];
oldGrp1 <- curDat[curDat$Group==1,]$Order;                  
oldGrp2 <- curDat[curDat$Group==2,]$Order;
#for(row in 1:1000){ 
for(row in 1:nrow(gsData)){  todo <- (dSets-dsId) + PsdSet[row];
    if ( dsId < minSet || (dsId >= minSet && todo >= dSets*psdSets ) )  {    
	xprd <- xprData[gsData[row,2:ncol(gsData)],c(curDat$Order)];
	fny <- fanny ( t(xprd),2,memb.exp=1.2);
	curDat$Fanny<-fny$clustering;
	newGrp1 <- curDat[curDat$Fanny==1,]$Order;
        newGrp2 <- curDat[curDat$Fanny==2,]$Order;
	newSiz1    <- length ( newGrp1 );
        newSiz2 <- length( newGrp2 );
       
	ss <- matrix(1,2,2);
	inter11 <- length(intersect(oldGrp1,newGrp1));
        inter12 <- length(intersect(oldGrp1,newGrp2));
	inter21 <- length(intersect(oldGrp2,newGrp1));
        inter22 <- length(intersect(oldGrp2,newGrp2));
	ss[1,1] = inter11;
        ss[1,2] = inter12;
        ss[2,1] = inter21;
        ss[2,2] = inter22;
	#print (ss);
	if ( min(newSiz1,newSiz2) >= 1 ) {   
	    PValues[row,dsId] <- as.numeric(format(fisher.test(ss)$p.value,digits=2));
	    if ( PValues[row,dsId] <= minPvl ) { PsdSet[row] = PsdSet[row] + 1  };
	}
    }
}
}
# ------>    Done.

# ------>    Save the results.
val <- cbind(SetId=gsData[,1],PValue=PValues);
outFile <- paste(wrkDir,"/results/",run,"/",dataSet,'_PValues_',gset,'.csv',sep='');
write.csv (val, outFile, row.names=F, quote=F);
# ------>    Done.
