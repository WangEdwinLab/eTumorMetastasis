args <- commandArgs()
#Depending on layer, taking the right directory.
dir<-ifelse(length(grep("founding",args[4])) > 0,"founding",
	ifelse(length(grep("clone50",args[4])) > 0,"50+",
		ifelse(length(grep("germ",args[4])) > 0,"germ","20-50")))
D <- as.matrix(read.csv(paste("/work/knode05/milanesej/metastasis/BRCA/network/propagation/emt2/",dir,"/input/",args[3],"_",args[4],"_int.csv",sep=""), header=T))
Adj <- as.matrix(read.csv(paste("/work/knode05/milanesej/metastasis/BRCA/network/propagation/emt2/",dir,"/input/",args[3],"_",args[4],"_adj.csv",sep=""), header=T))
Seeds <- as.matrix(read.csv(paste("/work/knode05/milanesej/metastasis/BRCA/network/propagation/emt2/",dir,"/input/",args[3],"_",args[4],"_seeds.csv",sep=""), header=T))

Genes <- as.vector( D[1:nrow(D),1])
AllGenes <- as.vector( D[,1])
D <- as.matrix( D[1:nrow(D),2:ncol(D)])
Adj <- as.matrix( Adj[1:nrow(Adj),2:ncol(Adj)])


Seeds <- match(AllGenes, Seeds, nomatch=0)


Seeds[Seeds > 1] <- 1

e <- Seeds
c = 0.7

#--- RWR
#	P <- Adj %*% D
#	r <- c*(P %*% e) + (1 - c)*(e)
#	
#	before <- norm(r, "F")
#	after <- norm(100*r, "F")
#	
#	while ( abs(after - before) > 10**(-6) ){
#		before <- norm(r, "F")
#		r <- c*(P %*% r) + (1 - c)*(e)
#		after <- norm(r, "F")
#	}
#	r <- as.vector(r)
#	r <- cbind( Genes, r)
#	write.table(r, NAMES[4], sep="\t", quote=F, row.names=F, col.names=F)
	
#--- PROP
P <- D %*% Adj %*% D
r <- c*(P %*% e) + (1 - c)*(e)

before <- norm(r, "F")
after <- norm(100000*r, "F")

while ( abs(after - before) > 10**(-9) ){
	before <- norm(r, "F")
	r <- c*(P %*% r) + (1 - c)*(e)
	after <- norm(r, "F")
}
r <- as.vector(r)
r <- cbind( Genes, r)
write.table(r,paste("/work/knode05/milanesej/metastasis/BRCA/network/propagation/emt2/",dir,"/results/",args[3],"_",args[4],"_prop.csv",sep=""), sep="\t", quote=F, row.names=F, col.names=F)
